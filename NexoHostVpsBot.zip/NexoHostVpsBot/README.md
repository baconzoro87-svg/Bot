# NexoHost VPS Bot

## Main system
- Prefix: `-`
- Self-service deployment: `-deploy`
- Message check: `-msg`
- Only the command author can deploy their own VPS; there is no target-user deploy option.
- One active self-service VPS per user.

## Message-based deployment
- `500` messages -> `4GB RAM / 1 Core / 20GB Disk`
- `1000` messages -> `8GB RAM / 2 Cores / 40GB Disk`
- When a VPS is successfully deployed, that user's message counter resets to `0`.

## Renewal
- VPS starts with `30 days`.
- At day `28`, if the renewal target is complete, the bot automatically adds `+28 days`.
- `4GB VPS` renewal target: `300` messages.
- `8GB VPS` renewal target: `500` messages.
- When auto-renewed, the message counter resets to `0` for the new cycle.
- If the target is not complete, the user receives a DM `10 days` before expiry and is told to use `-msg`.
- If the target is still incomplete at expiry, the existing expiration system suspends the VPS.

## Vouch + activity
- First message in the configured vouch channel records the user's one-time vouch.
- Future deployments/renewals do not require another vouch.
- The 30-minute activity rule is separate: an active VPS owner must send a message in the vouch/activity channel within 30 minutes or the VPS is automatically suspended.

## Discord roles
- Owner/admin role: `1525068173739688131`
- Free VPS deploy role: `1532689286602821703`
- Vouch/activity channel: `1549001548242358272`

## Required Discord intents
Enable **Message Content Intent** in the Discord Developer Portal. The bot also needs View Channels, Send Messages, Read Message History, Embed Links, Manage Roles, and the bot role must be above the VPS user role.


### Network
No public IP environment variable is required. The bot automatically detects the host public IP when it needs to display SSH port-forward information. For NAT/private hosts, use the built-in SSHX/tmate access options.
